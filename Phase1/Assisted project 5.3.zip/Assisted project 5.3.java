package assisted5;

import java.util.Scanner;

public class Exponential {
    public static int exponentialSearch(int[] arr, int target) {
        int n = arr.length;
        
        if (arr[0] == target) {
            return 0;
        }
        
     
        int i = 1;
        while (i < n && arr[i] <= target) {
            i *= 2;
        }
        
        return binarySearch(arr, target, i / 2, Math.min(i, n - 1));
    }
    
    public static int binarySearch(int[] arr, int target, int left, int right) {
        while (left <= right) {
            int mid = left + (right - left) / 2;
            
            if (arr[mid] == target) {
                return mid; 
            }
            
            if (arr[mid] < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        
        return -1; 
    }

    public static void main(String[] args) {
        int[] sortedMultiples = {6, 12, 18, 24, 30, 36}; 

       
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number to search for: ");
        int targetElement = scanner.nextInt();

        int result = exponentialSearch(sortedMultiples, targetElement);

        if (result != -1) {
            System.out.println("Element " + targetElement + " found at index " + result);
        } else {
            System.out.println("Element " + targetElement + " not found in the array.");
        }

        scanner.close();
    }
}
