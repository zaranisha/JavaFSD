package Assessmentproject;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Login {
    private List<User> users;

    public Login() {
        users = new ArrayList<>();
 
        users.add(new User("roronoa", "roronoa20"));
        users.add(new User("zoro", "zoro27"));
        users.add(new User("nammi", "nammi15"));
        users.add(new User("buggy", "buggy17"));
        users.add(new User("luffy", "luffy05"));
        users.add(new User("kaiya", "kaiya08"));
        users.add(new User("usoop", "usoop12"));
    }

    public User authenticate(Scanner scanner) {
        System.out.println("+--------------------------------+");
        System.out.println("| WELCOME TO BUDGET TRACKER APP  |");
        System.out.println("+--------------------------------+");
        System.out.println("\nPlease login to continue");
        System.out.println("\nEnter your username: ");
        String enteredUsername = scanner.nextLine();
        System.out.println("Enter your password: ");
        String enteredPassword = scanner.nextLine();

        for (User user : users) {
            if (user.getUsername().equals(enteredUsername) && user.getPassword().equals(enteredPassword)) {
                return user; // Authentication successful
            }
        }

        return null; // Authentication failed
    }
}
