package SpringHibernateWeb.SpringHibernateWeb.vo;

/**
 * 基本VO字段
 */
public class BaseVO {
}