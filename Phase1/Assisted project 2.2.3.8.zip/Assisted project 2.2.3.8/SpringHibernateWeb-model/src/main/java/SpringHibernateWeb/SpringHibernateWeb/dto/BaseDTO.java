package SpringHibernateWeb.SpringHibernateWeb.dto;

/**
 * 基本DTO字段
 */
public class BaseDTO {
}