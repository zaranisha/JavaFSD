package assisted4;

import java.util.Scanner;

public class Matrix {
    public static void main(String[] args) {
        int a[][] = new int[2][2];
        int b[][] = new int[2][2];
        int matrix = 2; 
        @SuppressWarnings("resource")
		Scanner sc= new Scanner(System.in);
        // Input for the first matrix
        System.out.println("Enter the first matrix:");
        for (int row = 0; row < matrix; row++) {
            for (int col = 0; col < matrix; col++) {
                System.out.print("Enter value for row " + (row + 1) + " and column " + (col + 1) + ": ");
                a[row][col] = sc.nextInt();
            }
        }

        // Input for the second matrix
        System.out.println("Enter the second matrix:");
        for (int row = 0; row < matrix; row++) {
            for (int col = 0; col < matrix; col++) {
                System.out.print("Enter value for row " + (row + 1) + " and column " + (col + 1) + ": ");
                b[row][col] = sc.nextInt();
            }
        }

        // Output matrix form
        System.out.println("Output:");

        for (int row = 0; row < matrix; row++) {
            for (int col = 0; col < matrix; col++) {
                System.out.print(a[row][col] + b[row][col] + " ");
            }
            System.out.println(); 
        }
    }
}
