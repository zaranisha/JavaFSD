package Assessmentproject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.HashMap;

public class ExpenseManager {

    private List<Map<String, String>> expenses;
    private User authenticatedUser;

    public ExpenseManager() {
        expenses = new ArrayList<>();
        authenticatedUser = null;
    }

    public void setAuthenticatedUser(User user) {
        authenticatedUser = user;
    }

    public void recordExpense(User user, Scanner scanner) {
        if (authenticatedUser == null) {
            System.out.println("Please log in to record expenses.");
            return;
        }

        System.out.println("Expense Types:");
        System.out.println("1. Cloth");
        System.out.println("2. Exam Fee");
        System.out.println("3. Food");
        System.out.println("4. Fuel");
        System.out.println("5. Electric bill");
        System.out.println("6. House rent");
        System.out.println("7. Traveling");
        System.out.println("8. Others");
        System.out.print("Enter the expense type (1/2/3/4/5/6/7/8): ");
        int expenseChoice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        String expenseType;
        switch (expenseChoice) {
            case 1:
                expenseType = "Cloth";
                break;
            case 2:
                expenseType = "Exam Fee";
                break;
            case 3:
                expenseType = "Food";
                break;
            case 4:
                expenseType = "Fuel";
                break;
            case 5:
                expenseType = "Electric bill";
                break;
            case 6:
                expenseType = "House rent";
                break;
            case 7:
                expenseType = "Traveling";
                break;
            case 8:
                expenseType = "Others";
                break;
            default:
                System.out.println("Invalid expense type.");
                return;
        }

        System.out.print("Enter the amount for " + expenseType + ": ");
        double amount = scanner.nextDouble();
        scanner.nextLine(); // Consume newline

        // Prompt the user to enter date and description
        System.out.print("Enter the date (e.g., MM/DD/YYYY): ");
        String date = scanner.nextLine();
        Date expenseDate;
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
            expenseDate = dateFormat.parse(date);
        } catch (ParseException e) {
            System.out.println("Invalid date format. Please enter a date in the format MM/DD/YYYY.");
            return;
        }

        System.out.print("Enter the description: ");
        String description = scanner.nextLine();

        // Ask for the user's password
        System.out.print("Enter your password to confirm: ");
        String enteredPassword = scanner.nextLine();

        // Check if the entered password matches the user's password
        if (authenticatedUser.getPassword().equals(enteredPassword)) {
            Map<String, String> expenseEntry = new HashMap<>();
            expenseEntry.put("User", authenticatedUser.getUsername());
            expenseEntry.put("Date", date);
            expenseEntry.put("Category", expenseType);
            expenseEntry.put("Description", description);
            expenseEntry.put("Amount", String.valueOf(amount));
            
            expenses.add(expenseEntry);
            System.out.println("Expense recorded for " + expenseType + ": $" + amount);
        } else {
            System.out.println("Password is incorrect. Expense not recorded.");
        }
    }
    public List<Map<String, String>> getDatewiseExpenses(String date) {
        List<Map<String, String>> datewiseExpenses = new ArrayList<>();
        
        for (Map<String, String> expense : expenses) {
            String expenseDateStr = expense.get("Date");
            SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
            
            try {
                Date expenseDate = dateFormat.parse(expenseDateStr);
                if (expenseDateStr.equals(date)) {
                    datewiseExpenses.add(expense);
                }
            } catch (ParseException e) {
                // Handle parsing errors if needed
                e.printStackTrace();
            }
        }
        
        return datewiseExpenses;
    }

    public List<Map<String, String>> getMonthwiseExpenses(int month) {
        List<Map<String, String>> monthwiseExpenses = new ArrayList<>();
        
        for (Map<String, String> expense : expenses) {
            String date = expense.get("Date");
            SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
            try {
                Date expenseDate = dateFormat.parse(date);
                Calendar cal = Calendar.getInstance();
                cal.setTime(expenseDate);
                int expenseMonth = cal.get(Calendar.MONTH) + 1; // Calendar.MONTH is zero-based
                if (expenseMonth == month) {
                    monthwiseExpenses.add(expense);
                }
            } catch (ParseException e) {
                // Handle parsing errors if needed
                e.printStackTrace();
            }
        }
        
        return monthwiseExpenses;
    }

    // You can add methods to display expenses or perform other expense-related operations
}
