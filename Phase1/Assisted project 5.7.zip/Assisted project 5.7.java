package assisted5;

public class Mergesort {
    public static void mergeSort(int[] arr) {
        int n = arr.length;

        if (n <= 1) {
            return; 
        }

        int mid = n / 2;
        int[] left = new int[mid];
        int[] right = new int[n - mid];


        for (int i = 0; i < mid; i++) {
            left[i] = arr[i];
        }
        for (int i = mid; i < n; i++) {
            right[i - mid] = arr[i];
        }

    
        mergeSort(left);
        mergeSort(right);

       
        int i = 0, j = 0, k = 0;
        while (i < mid && j < n - mid) {
            if (left[i] <= right[j]) {
                arr[k++] = left[i++];
            } else {
                arr[k++] = right[j++];
            }
        }

        
        while (i < mid) {
            arr[k++] = left[i++];
        }
        while (j < n - mid) {
            arr[k++] = right[j++];
        }
    }

    public static void printArray(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        int[] predefinedArray = {6,4, 2,5,9,7,3};

        
        mergeSort(predefinedArray);

        System.out.println("Sorted Array:");
        printArray(predefinedArray);
    }
}
