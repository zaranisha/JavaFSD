package Assessmentproject;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.ArrayList;

public class Budgetlog {
    private static final Map<String, String> userCredentials = new HashMap<>();
    private static final Map<String, List<Map<String, String>>> userBudgetLogs = new HashMap<>();

    // Define a static list of credentials
    private static final Map<String, String> staticCredentials = new HashMap<>();

    // Define a static list of expenses
    private static final List<Map<String, String>> staticExpenses = new ArrayList<>();

    static {
        // Initialize sample user credentials (username: password)
        userCredentials.put("zoro", "zoro27");
        
        

        // Add sample expenses (you can add more)
        Map<String, String> expense1 = new HashMap<>();
        expense1.put("date", "01-09-2023");
        expense1.put("category", "Food");
        expense1.put("amount", "50.00");
        Map<String, String> expense2 = new HashMap<>();
        expense2.put("date", "22-09-2023");
        expense2.put("category", "Travelling");
        expense2.put("amount", "30.00");
        Map<String, String> expense3 = new HashMap<>();
        expense3.put("date", "13-04-2023");
        expense3.put("category", "cloth");
        expense3.put("amount", "1000.00");
        Map<String, String> expense4 = new HashMap<>();
        expense4.put("date", "19-05-2023");
        expense4.put("category", "fee");
        expense4.put("amount", "1150.00");
        Map<String, String> expense5 = new HashMap<>();
        expense5.put("date", "01-09-2023");
        expense5.put("category", "others");
        expense5.put("amount", "5000.00");
        Map<String, String> expense6 = new HashMap<>();
        expense6.put("date", "11-01-2023");
        expense6.put("category", "Food");
        expense6.put("amount", "150.00");
        Map<String, String> expense7 = new HashMap<>();
        expense7.put("date", "20-10-2023");
        expense7.put("category", "electric bill");
        expense7.put("amount", "250.00");

        staticExpenses.add(expense1);
        staticExpenses.add(expense2);
        staticExpenses.add(expense3);
        staticExpenses.add(expense4);
        staticExpenses.add(expense5);
        staticExpenses.add(expense6);
        staticExpenses.add(expense7);
        
    }

    public static void main(String[] args) {
        Budgetlog budgetLog = new Budgetlog();
        budgetLog.run();
    }

    public void run() {
        String authenticatedUser = authenticateUser();
        System.out.println("Welcome, " + authenticatedUser + "!\n");

        while (true) {
            System.out.println("SELECT THE BUDGET LOG YOU WANT TO DISPLAY:");
            System.out.println("1. DATE-WISE LOG");
            System.out.println("2. MONTH-WISE LOG");
            System.out.println("3. TOTAL BUDGET");
            System.out.println("4. DELETE BUDGETARY LOG");
            System.out.println("5. Exit");

            Scanner scanner = new Scanner(System.in);
            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    System.out.print("Enter the date in DD-MM-YYYY format: ");
                    String dateInput = scanner.nextLine();
                    displayDatewiseLog(authenticatedUser, dateInput);
                    break;
                case "2":
                    System.out.print("Enter the month number (1 to 12): ");
                    int monthInput = Integer.parseInt(scanner.nextLine());
                    displayMonthwiseLog(authenticatedUser, monthInput);
                    break;
                case "3":
                    calculateTotalBudget(authenticatedUser);
                    break;
                case "4":
                    deleteBudgetaryLog(authenticatedUser);
                    break;
                case "5":
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please select a valid option.");
                    break;
            }
        }
    }

    private String authenticateUser() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.print("Enter your username: ");
            String username = scanner.nextLine();
            System.out.print("Enter your password: ");
            String password = scanner.nextLine();

            // Check credentials from both userCredentials and staticCredentials
            if ((userCredentials.containsKey(username) && userCredentials.get(username).equals(password)) ||
                (staticCredentials.containsKey(username) && staticCredentials.get(username).equals(password))) {
                return username;
            } else {
                System.out.println("Invalid credentials. Please try again.");
            }
        }
    }

    private void displayDatewiseLog(String username, String date) {
        System.out.println("\nDATE-WISE LOG FOR " + date + " (User: " + username + "):");
        List<Map<String, String>> userLogs = userBudgetLogs.getOrDefault(username, new ArrayList<>());

        // Simulate expenses for the specified date
        List<Map<String, String>> datewiseExpenses = new ArrayList<>();
        
        // Populate datewiseExpenses with expenses for the specified date
        for (Map<String, String> expense : staticExpenses) {
            if (expense.get("date").equals(date)) {
                datewiseExpenses.add(expense);
            }
        }

        if (datewiseExpenses.isEmpty()) {
            System.out.println("No expenses found for the specified date.");
        } else {
            for (Map<String, String> log : datewiseExpenses) {
                System.out.println("Date: " + log.get("date") + ", Category: " + log.get("category") + ", Amount: $" + log.get("amount"));
            }
        }
    }


    private void displayMonthwiseLog(String username, int month) {
        System.out.println("\nMONTH-WISE LOG FOR MONTH " + month + " (User: " + username + "):");
        List<Map<String, String>> userLogs = userBudgetLogs.getOrDefault(username, new ArrayList<>());

        // Simulate expenses for the specified month
        List<Map<String, String>> monthwiseExpenses = new ArrayList<>();
        for (Map<String, String> expense : staticExpenses) {
            int expenseMonth = Integer.parseInt(expense.get("date").split("-")[1]);
            if (expenseMonth == month) {
                monthwiseExpenses.add(expense);
            }
        }

        for (Map<String, String> log : monthwiseExpenses) {
            System.out.println("Date: " + log.get("date") + ", Category: " + log.get("category") + ", Amount: $" + log.get("amount"));
        }
    }

    private void calculateTotalBudget(String username) {
        // Simulate a monthly budget for the user
        double totalBudget = 1000.0; // Set your initial total budget here
        double totalSpending = 0.0;

        // Calculate total spending based on staticExpenses
        for (Map<String, String> expense : staticExpenses) {
            totalSpending += Double.parseDouble(expense.get("amount"));
        }

        double currentBudget = totalBudget - totalSpending;

        System.out.println("\nMONTHLY BUDGET (User: " + username + "):");
        System.out.println("TOTAL BUDGET: $" + String.format("%.2f", totalBudget));
        System.out.println("CURRENT BUDGET: $" + String.format("%.2f", currentBudget));
        System.out.println("TOTAL SPENDING : $" + String.format("%.2f", totalSpending));
    }


    private void deleteBudgetaryLog(String username) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the month number (1 to 12) for which you want to delete expenses: ");
        int monthInput = Integer.parseInt(scanner.nextLine());

        // Create a list to store expenses without the selected month's expenses
        List<Map<String, String>> updatedExpenses = new ArrayList<>();

        for (Map<String, String> expense : staticExpenses) {
            int expenseMonth = Integer.parseInt(expense.get("date").split("-")[1]);
            if (expenseMonth != monthInput) {
                updatedExpenses.add(expense);
            }
        }

        // Update the staticExpenses with the updated list
        staticExpenses.clear();
        staticExpenses.addAll(updatedExpenses);

        System.out.println("Expenses for the selected month deleted successfully! (User: " + username + ")");
    }

}
