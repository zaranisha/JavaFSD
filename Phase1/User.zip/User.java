package Assessmentproject;

public class User {
    private String username;
    private String password;
    private double monthlyBudget;
    private String date;
    private String category;
    private String description;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
        this.monthlyBudget = 0.0;
        this.date = "";
        this.category = "";
        this.description = "";
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public double getMonthlyBudget() {
        return monthlyBudget;
    }

    public void setMonthlyBudget(double monthlyBudget) {
        this.monthlyBudget = monthlyBudget;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
