package assisted5;

import java.util.Scanner;

	public class Linear {
	    public static int linearSearch(int[] arr, int target) {
	        for (int i = 0; i < arr.length; i++) {
	            if (arr[i] == target) {
	                return i; 
	            }
	        }
	        return -1; 
	    }

	    public static void main(String[] args) {
	        int[] multiplesOfTen = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};

	       
	        Scanner scanner = new Scanner(System.in);

	        System.out.print("Enter the number to search for: ");
	        int targetElement = scanner.nextInt();

	        int result = linearSearch(multiplesOfTen, targetElement);

	        if (result != -1) {
	            System.out.println("Element " + targetElement + " found at index " + result);
	        } else {
	            System.out.println("Element " + targetElement + " not found in the array.");
	        }

	        
	        scanner.close();
	    }
	}



