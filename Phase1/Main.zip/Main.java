package Assessmentproject;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        User authenticatedUser = null;

        Login login = new Login();

        while (authenticatedUser == null) {
            authenticatedUser = login.authenticate(scanner);
            if (authenticatedUser == null) {
                System.out.println("Login failed. Invalid username or password.");
            }
        }

        while (true) {
            displayMainMenu();

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    // Set or update the monthly budget
                    double monthlyBudget = authenticatedUser.getMonthlyBudget();
                    if (monthlyBudget == 0.0) {
                        monthlyBudget = Setbudget.setMonthlyBudget(scanner, authenticatedUser);
                    } else {
                        monthlyBudget = Setbudget.updateMonthlyBudget(scanner, authenticatedUser);
                    }
                    authenticatedUser.setMonthlyBudget(monthlyBudget); // Update the user's budget
                    break;
                case 2:
                    if (authenticatedUser != null) { // Check if the user is authenticated
                        ExpenseManager expenseManager = new ExpenseManager();
                        expenseManager.setAuthenticatedUser(authenticatedUser); // Set authenticated user
                        expenseManager.recordExpense(authenticatedUser, scanner);
                    } else {
                        System.out.println("Please log in to record expenses.");
                    }
                    break;
                    
                case 3:
                    if (authenticatedUser != null) { // Check if the user is authenticated
                        Budgetlog budgetLog = new Budgetlog();
                        budgetLog.run(); // Call the run method in the Budgetlog class
                    } else {
                        System.out.println("Please log in to access budgetary logs.");
                    }
                    break;



                case 4:
                    // Change Password
                	 Passwordchange.changePassword(authenticatedUser.getUsername(), authenticatedUser.getPassword(), scanner);
                    break;
                case 5:
                    // Exit the program
                    System.out.println("Exiting. Goodbye!");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please select a valid option.");
            }
        }
    }

    private static void displayMainMenu() {
        System.out.println("Menu:");
        System.out.println(" ");
        System.out.println("1. Set Monthly Budget");
        System.out.println("2. Record an Expense");
        System.out.println("3. Budgetary Logs");
        System.out.println("4. Change Password");
        System.out.println("5. Exit");
        System.out.println(" ");
        System.out.print("Enter your choice: ");
    }
}
